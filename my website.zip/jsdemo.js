$('#open-popup').magnificPopup({
    items: [
      {
        src: "img/mmprt/mmpic1.jpg",
        title: 'login page'
      },
	  {
        src: "img/mmprt/mmpic2.jpg",
        title: 'welcome page'
      },
	  {
        src: "img/mmprt/mmpic3.jpg",
        title: 'Peter & Paul fortress in SPB'
      },
	  {
        src: "img/mmprt/mmpic4.jpg",
        title: 'login page'
      },
	  {
        src: "img/mmprt/mmpic5.jpg",
        title: 'welcome page'
      },
	  {
        src: "img/mmprt/mmpic6.jpg",
        title: 'Peter & Paul fortress in SPB'
      },
	  {
        src: "img/mmprt/mmpic7.jpg",
        title: 'login page'
      },
	  {
        src: "img/mmprt/mmpic8.jpg",
        title: 'welcome page'
      },
	  {
        src: "img/mmprt/mmpic9.jpg",
        title: 'Peter & Paul fortress in SPB'
      },
	  {
        src: "img/mmprt/mmpic10.jpg",
        title: 'login page'
      },
	  {
        src: "img/mmprt/mmpic11.jpg",
        title: 'welcome page'
      },
	  {
        src: "img/mmprt/mmpic12.jpg",
        title: 'Peter & Paul fortress in SPB'
      },
	  {
        src: "img/mmprt/mmpic13.jpg",
        title: 'login page'
      },
	  {
        src: "img/mmprt/mmpic14.jpg",
        title: 'welcome page'
      },
	  {
        src: "img/mmprt/mmpic15.jpg",
        title: 'Peter & Paul fortress in SPB'
      },
	  {
        src: "img/mmprt/mmpic16.jpg",
        title: 'login page'
      },
	  {
        src: "img/mmprt/mmpic17.jpg",
        title: 'welcome page'
      },
	  {
        src: "img/mmprt/mmpic18.jpg",
        title: 'Peter & Paul fortress in SPB'
      },
	  {
        src: "img/mmprt/mmpic19.jpg",
        title: 'login page'
      },
	  {
        src: "img/mmprt/mmpic20.jpg",
        title: 'welcome page'
      },
	  {
        src: "img/mmprt/mmpic21.jpg",
        title: 'Peter & Paul fortress in SPB'
      },
      {
        src: "img/mmprt/mmpic22.jpg",
        title: 'login page'
      },
	  {
        src: "img/mmprt/mmpic23.jpg",
        title: 'welcome page'
      },
	  {
        src: "img/mmprt/mmpic24.jpg",
        title: 'login page'
      },
	  {
        src: "img/mmprt/mmpic25.jpg",
        title: 'welcome page'
      }
	  
    ],
    gallery: {
      enabled: true
    },
    type: 'image' // this is a default type
});