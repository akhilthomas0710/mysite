$('#openpopup').magnificPopup({
    items: [
      {
        src: "img/cmmprt/cmm1.png",
        title: 'login page'
      },
	  {
        src: "img/cmmprt/cmm2.png",
        title: 'welcome page'
      },
	  {
        src: "img/cmmprt/cmm3.png",
        title: 'Peter & Paul fortress in SPB'
      },
	  {
        src: "img/cmmprt/cmm4.png",
        title: 'login page'
      },
	  {
        src: "img/cmmprt/cmm5.png",
        title: 'welcome page'
      }
	 
	 
	 
	  
	  
    ],
    gallery: {
      enabled: true
    },
    type: 'image' // this is a default type
});